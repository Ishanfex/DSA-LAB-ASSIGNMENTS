
#include <bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node *left,*right;
    Node(int v): data(v), left(nullptr), right(nullptr) {}
};

bool isBSTUtil(Node* node, long long minv, long long maxv){
    if(!node) return true;
    if(node->data <= minv || node->data >= maxv) return false;
    return isBSTUtil(node->left, minv, node->data) && isBSTUtil(node->right, node->data, maxv);
}
bool isBST(Node* root){
    return isBSTUtil(root, LLONG_MIN, LLONG_MAX);
}

int main(){
    // Example 1: valid BST
    Node* bst = new Node(20);
    bst->left = new Node(10);
    bst->right = new Node(30);
    bst->left->left = new Node(5);
    bst->left->right = new Node(15);

    // Example 2: not a BST
    Node* notbst = new Node(20);
    notbst->left = new Node(30); // invalid
    notbst->right = new Node(40);

    cout<<"First tree is BST? "<<(isBST(bst) ? "Yes":"No")<<"\n";
    cout<<"Second tree is BST? "<<(isBST(notbst) ? "Yes":"No")<<"\n";

    return 0;
}
