
#include <bits/stdc++.h>
using namespace std;

struct Node {
    int key;
    Node *left,*right;
    Node(int k): key(k), left(nullptr), right(nullptr) {}
};

Node* insertNode(Node* root, int key){
    if(!root) return new Node(key);
    if(key < root->key) root->left = insertNode(root->left, key);
    else if(key > root->key) root->right = insertNode(root->right, key);
    // duplicates ignored
    return root;
}

Node* findMinNode(Node* root){
    Node* cur = root;
    while(cur && cur->left) cur = cur->left;
    return cur;
}

Node* deleteNode(Node* root, int key){
    if(!root) return nullptr;
    if(key < root->key) root->left = deleteNode(root->left, key);
    else if(key > root->key) root->right = deleteNode(root->right, key);
    else {
        // found
        if(!root->left){
            Node* r = root->right;
            delete root;
            return r;
        } else if(!root->right){
            Node* l = root->left;
            delete root;
            return l;
        } else {
            Node* succ = findMinNode(root->right);
            root->key = succ->key;
            root->right = deleteNode(root->right, succ->key);
        }
    }
    return root;
}

int maxDepth(Node* root){
    if(!root) return 0;
    return 1 + max(maxDepth(root->left), maxDepth(root->right));
}
int minDepth(Node* root){
    if(!root) return 0;
    if(!root->left) return 1 + minDepth(root->right);
    if(!root->right) return 1 + minDepth(root->left);
    return 1 + min(minDepth(root->left), minDepth(root->right));
}

void inorderPrint(Node* root){
    if(!root) return;
    inorderPrint(root->left);
    cout<<root->key<<" ";
    inorderPrint(root->right);
}

int main(){
    vector<int> vals = {50,30,20,40,70,60,80,65};
    Node* root = nullptr;
    for(int v: vals) root = insertNode(root, v);

    cout<<"BST (in-order) after inserts: ";
    inorderPrint(root);
    cout<<"\n";

    cout<<"Max depth: "<<maxDepth(root)<<"\n";
    cout<<"Min depth: "<<minDepth(root)<<"\n";

    cout<<"Deleting 20 (leaf)\n";
    root = deleteNode(root, 20);
    cout<<"In-order: "; inorderPrint(root); cout<<"\n";

    cout<<"Deleting 30 (node with one child)\n";
    root = deleteNode(root, 30);
    cout<<"In-order: "; inorderPrint(root); cout<<"\n";

    cout<<"Deleting 50 (node with two children - root)\n";
    root = deleteNode(root, 50);
    cout<<"In-order: "; inorderPrint(root); cout<<"\n";

    cout<<"Max depth after deletions: "<<maxDepth(root)<<"\n";
    cout<<"Min depth after deletions: "<<minDepth(root)<<"\n";

    return 0;
}
