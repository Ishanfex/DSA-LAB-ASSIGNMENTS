
#include <bits/stdc++.h>
using namespace std;

struct Node {
    int key;
    Node *left,*right;
    Node(int k): key(k), left(nullptr), right(nullptr) {}
};

Node* insertNode(Node* root, int key){
    if(!root) return new Node(key);
    if(key < root->key) root->left = insertNode(root->left, key);
    else if(key > root->key) root->right = insertNode(root->right, key);
    return root;
}

// Recursive search
Node* searchRec(Node* root, int key){
    if(!root || root->key==key) return root;
    return key < root->key ? searchRec(root->left, key) : searchRec(root->right, key);
}

// Iterative search
Node* searchIter(Node* root, int key){
    Node* cur = root;
    while(cur){
        if(cur->key==key) return cur;
        cur = (key < cur->key) ? cur->left : cur->right;
    }
    return nullptr;
}

int findMin(Node* root){
    if(!root) throw runtime_error("Empty tree");
    Node* cur = root;
    while(cur->left) cur = cur->left;
    return cur->key;
}
int findMax(Node* root){
    if(!root) throw runtime_error("Empty tree");
    Node* cur = root;
    while(cur->right) cur = cur->right;
    return cur->key;
}

// Inorder successor of given key (returns INT_MIN if none)
Node* findNode(Node* root, int key){
    if(!root) return nullptr;
    if(root->key==key) return root;
    return key < root->key ? findNode(root->left, key) : findNode(root->right, key);
}

Node* inorderSuccessor(Node* root, int key){
    Node* target = findNode(root, key);
    if(!target) return nullptr;
    // Case 1: has right subtree -> min in right
    if(target->right){
        Node* cur = target->right;
        while(cur->left) cur = cur->left;
        return cur;
    }
    // Case 2: walk from root and track successor
    Node* succ = nullptr;
    Node* cur = root;
    while(cur){
        if(key < cur->key){ succ = cur; cur = cur->left;}
        else if(key > cur->key) cur = cur->right;
        else break;
    }
    return succ;
}

Node* inorderPredecessor(Node* root, int key){
    Node* target = findNode(root, key);
    if(!target) return nullptr;
    if(target->left){
        Node* cur = target->left;
        while(cur->right) cur = cur->right;
        return cur;
    }
    Node* pred = nullptr;
    Node* cur = root;
    while(cur){
        if(key > cur->key){ pred = cur; cur = cur->right;}
        else if(key < cur->key) cur = cur->left;
        else break;
    }
    return pred;
}

void inorderPrint(Node* root){
    if(!root) return;
    inorderPrint(root->left);
    cout<<root->key<<" ";
    inorderPrint(root->right);
}

int main(){
    vector<int> vals = {20,10,5,15,30,25,35,22,27};
    Node* root = nullptr;
    for(int v: vals) root = insertNode(root, v);

    cout<<"BST (in-order): ";
    inorderPrint(root);
    cout<<"\n";

    int s1 = 15, s2 = 100;
    cout<<"Search recursive "<<s1<<": "<< (searchRec(root,s1)? "Found":"Not Found")<<"\n";
    cout<<"Search iterative "<<s2<<": "<< (searchIter(root,s2)? "Found":"Not Found")<<"\n";

    cout<<"Minimum element: "<<findMin(root)<<"\n";
    cout<<"Maximum element: "<<findMax(root)<<"\n";

    int key = 25;
    Node* succ = inorderSuccessor(root, key);
    if(succ) cout<<"In-order successor of "<<key<<": "<<succ->key<<"\n";
    else cout<<"In-order successor of "<<key<<": None\n";

    Node* pred = inorderPredecessor(root, key);
    if(pred) cout<<"In-order predecessor of "<<key<<": "<<pred->key<<"\n";
    else cout<<"In-order predecessor of "<<key<<": None\n";

    return 0;
}
