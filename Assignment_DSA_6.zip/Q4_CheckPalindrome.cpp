#include <iostream>
using namespace std;

struct Node { char data; Node* next; Node* prev; };

bool isPalindrome(Node* head) {
    if (!head) return true;
    Node* left = head; Node* right = head;
    while (right->next) right = right->next;
    while (left != right && right->next != left) {
        if (left->data != right->data) return false;
        left = left->next; right = right->prev;
    }
    return true;
}

int main() {
    Node* a = new Node{'r', nullptr, nullptr};
    Node* b = new Node{'a', nullptr, a}; a->next = b;
    Node* c = new Node{'d', nullptr, b}; b->next = c;
    Node* d = new Node{'a', nullptr, c}; c->next = d;
    Node* e = new Node{'r', nullptr, d}; d->next = e;
    cout << (isPalindrome(a) ? "Palindrome" : "Not Palindrome") << endl;
    return 0;
}
