#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node* prev;
};

// Doubly Linked List
class DoublyLinkedList {
    Node* head;
public:
    DoublyLinkedList() { head = nullptr; }
    void insertFirst(int data) {
        Node* n = new Node{data, nullptr, nullptr};
        if (!head) head = n;
        else { n->next = head; head->prev = n; head = n; }
    }
    void insertLast(int data) {
        Node* n = new Node{data, nullptr, nullptr};
        if (!head) { head = n; return; }
        Node* t = head; while (t->next) t = t->next;
        t->next = n; n->prev = t;
    }
    void insertAfter(int key, int data) {
        Node* t = head; while (t && t->data != key) t = t->next;
        if (!t) { cout << "Key not found\n"; return; }
        Node* n = new Node{data, t->next, t};
        if (t->next) t->next->prev = n;
        t->next = n;
    }
    void insertBefore(int key, int data) {
        Node* t = head; while (t && t->data != key) t = t->next;
        if (!t) { cout << "Key not found\n"; return; }
        Node* n = new Node{data, t, t->prev};
        if (t->prev) t->prev->next = n; else head = n;
        t->prev = n;
    }
    void deleteNode(int key) {
        Node* t = head; while (t && t->data != key) t = t->next;
        if (!t) { cout << "Node not found\n"; return; }
        if (t->prev) t->prev->next = t->next; else head = t->next;
        if (t->next) t->next->prev = t->prev;
        delete t;
    }
    void search(int key) {
        Node* t = head; while (t) {
            if (t->data == key) { cout << "Node found\n"; return; }
            t = t->next;
        } cout << "Node not found\n";
    }
    void display() {
        Node* t = head;
        while (t) { cout << t->data << " "; t = t->next; }
        cout << endl;
    }
};

// Circular Linked List
class CircularLinkedList {
    Node* head;
public:
    CircularLinkedList() { head = nullptr; }
    void insertFirst(int data) {
        Node* n = new Node{data, nullptr, nullptr};
        if (!head) { head = n; n->next = head; }
        else {
            Node* t = head;
            while (t->next != head) t = t->next;
            n->next = head; t->next = n; head = n;
        }
    }
    void insertLast(int data) {
        Node* n = new Node{data, nullptr, nullptr};
        if (!head) { head = n; n->next = head; return; }
        Node* t = head; while (t->next != head) t = t->next;
        t->next = n; n->next = head;
    }
    void deleteNode(int key) {
        if (!head) return;
        Node* curr = head; Node* prev = nullptr;
        if (curr->data == key) {
            while (curr->next != head) curr = curr->next;
            curr->next = head->next; delete head; head = curr->next; return;
        }
        curr = head;
        do { prev = curr; curr = curr->next;
            if (curr->data == key) { prev->next = curr->next; delete curr; return; }
        } while (curr != head);
    }
    void search(int key) {
        if (!head) return;
        Node* t = head;
        do { if (t->data == key) { cout << "Node found\n"; return; }
             t = t->next;
        } while (t != head);
        cout << "Node not found\n";
    }
    void display() {
        if (!head) return;
        Node* t = head;
        do { cout << t->data << " "; t = t->next; } while (t != head);
        cout << head->data << endl;
    }
};

int main() {
    DoublyLinkedList dll;
    CircularLinkedList cll;
    dll.insertFirst(20);
    dll.insertLast(40);
    dll.insertAfter(20, 30);
    cout << "Doubly Linked List: "; dll.display();
    cll.insertLast(20); cll.insertLast(100); cll.insertLast(40);
    cll.insertLast(80); cll.insertLast(60);
    cout << "Circular Linked List: "; cll.display();
    return 0;
}
