#include <iostream>
using namespace std;

struct Node { int data; Node* next; };

bool isCircular(Node* head) {
    if (!head) return false;
    Node* t = head->next;
    while (t && t != head) t = t->next;
    return (t == head);
}

int main() {
    Node* a = new Node{1, nullptr};
    Node* b = new Node{2, nullptr};
    Node* c = new Node{3, nullptr};
    a->next = b; b->next = c; c->next = a; // circular
    cout << (isCircular(a) ? "Circular" : "Not Circular") << endl;
    return 0;
}
