#include <iostream>
using namespace std;

struct Node { int data; Node* next; };

void display(Node* head) {
    Node* temp = head;
    if (!head) return;
    do { cout << temp->data << " "; temp = temp->next; }
    while (temp != head);
    cout << head->data << endl;
}

int main() {
    Node* head = new Node{20, nullptr};
    Node* n2 = new Node{100, nullptr};
    Node* n3 = new Node{40, nullptr};
    Node* n4 = new Node{80, nullptr};
    Node* n5 = new Node{60, nullptr};
    head->next = n2; n2->next = n3; n3->next = n4; n4->next = n5; n5->next = head;
    cout << "Output: "; display(head);
    return 0;
}
