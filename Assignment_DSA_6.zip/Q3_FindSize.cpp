#include <iostream>
using namespace std;

struct Node { int data; Node* next; Node* prev; };

int sizeDoubly(Node* head) {
    int c = 0; while (head) { c++; head = head->next; } return c;
}

int sizeCircular(Node* head) {
    if (!head) return 0;
    int c = 0; Node* t = head;
    do { c++; t = t->next; } while (t != head);
    return c;
}

int main() {
    Node* d1 = new Node{10, nullptr, nullptr};
    Node* d2 = new Node{20, nullptr, d1}; d1->next = d2;
    cout << "Size of Doubly Linked List: " << sizeDoubly(d1) << endl;

    Node* c1 = new Node{20, nullptr, nullptr};
    Node* c2 = new Node{30, nullptr, nullptr};
    Node* c3 = new Node{40, nullptr, nullptr};
    c1->next = c2; c2->next = c3; c3->next = c1;
    cout << "Size of Circular Linked List: " << sizeCircular(c1) << endl;
    return 0;
}
